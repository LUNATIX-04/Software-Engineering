"use client"

import { useMemo, useState } from "react"

import {
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Edit3,
  Link2,
  MoreHorizontal,
  Plus,
  Search,
  Trash2,
  UserRound,
} from "lucide-react"

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

type ProjectTab = "Member" | "Department" | "Task" | "Calendar" | "Profile"

const TABS: ProjectTab[] = ["Member", "Department", "Task", "Calendar", "Profile"]

const SEARCH_INPUT_CLASS =
  "w-full rounded-full border-2 border-[#c7b2ff] bg-white/80 px-12 py-3 text-[#3a2d6d] placeholder:text-[#a08cd9] shadow-[0_6px_0_#e3d4ff] focus:outline-none focus:ring-2 focus:ring-[#8f75ff]"

export default function ProjectDetailPage() {
  const [activeTab, setActiveTab] = useState<ProjectTab>("Profile")

  const headerSubtitle = useMemo(() => {
    switch (activeTab) {
      case "Member":
        return "Manage the people who belong to this project."
      case "Department":
        return "Organize departments and their leads."
      case "Task":
        return "Track task progress across departments."
      case "Calendar":
        return "Visualize work across the month."
      case "Profile":
        return "Personalize your presence in this project."
      default:
        return ""
    }
  }, [activeTab])

  return (
    <div className="flex min-h-screen flex-col bg-[#fdf8ff] text-[#2f1c5a]">
      <header className="bg-gradient-to-b from-[#7e5ed6] to-[#b39bff] text-white shadow-[0_10px_0_#dcc8ff]">
        <div className="mx-auto flex w-full max-w-[min(90vw,110rem)] flex-col px-8">
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center gap-10">
              <span className="text-3xl font-black tracking-[0.35em]">ASAP</span>
              <span className="text-xl font-semibold tracking-wider">Project</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex size-12 items-center justify-center rounded-full border border-white/40 bg-white/20">
                <UserRound className="size-7" strokeWidth={2} />
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="inline-flex size-12 items-center justify-center rounded-full border border-white/40 bg-white/10 hover:bg-white/20 transition-colors">
                    <MoreHorizontal className="size-6" strokeWidth={2.5} />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="end"
                  sideOffset={12}
                  className="w-56 rounded-3xl border-none bg-[#f3e9ff] px-4 py-3 text-[#2f1c5a] shadow-[0_12px_0_#d6c0ff]"
                >
                  <DropdownMenuItem className="flex items-center gap-3 rounded-2xl px-3 py-3 text-base font-medium text-[#483183] hover:bg-white/80">
                    <Link2 className="size-4" />
                    Invite Link
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex items-center gap-3 rounded-2xl px-3 py-3 text-base font-medium text-[#483183] hover:bg-white/80">
                    <Edit3 className="size-4" />
                    Edit Project
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex items-center gap-3 rounded-2xl px-3 py-3 text-base font-medium text-[#ff4d6d] hover:bg-white/80 focus:text-[#ff4d6d]">
                    <Trash2 className="size-4" />
                    Delete Project
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          <nav className="flex items-center gap-4 rounded-t-3xl bg-white/25 px-3 pt-2">
            {TABS.map((tab) => {
              const isActive = activeTab === tab
              return (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setActiveTab(tab)}
                  className={`relative mx-2 flex flex-col items-center gap-2 px-4 pb-3 pt-4 text-base font-semibold tracking-wide transition-colors ${
                    isActive ? "text-[#2f1c5a]" : "text-white/70 hover:text-white"
                  }`}
                >
                  {tab}
                  {isActive ? (
                    <span className="absolute bottom-0 left-4 right-4 h-[6px] rounded-full bg-white" />
                  ) : null}
                </button>
              )
            })}
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <div className="mx-auto flex w-full max-w-[min(90vw,110rem)] flex-col gap-12 px-8 py-12">
          <div className="flex flex-col gap-2">
            <h1 className="text-4xl font-bold tracking-tight">{activeTab}</h1>
            <p className="text-lg text-[#6c5a9d]">{headerSubtitle}</p>
          </div>
          {renderActiveTab(activeTab)}
        </div>
      </main>

      <footer className="h-16 bg-[#4a3a8a]" />
    </div>
  )
}

function renderActiveTab(tab: ProjectTab) {
  switch (tab) {
    case "Member":
      return <MemberSection />
    case "Department":
      return <DepartmentSection />
    case "Task":
      return <TaskSection />
    case "Calendar":
      return <CalendarSection />
    case "Profile":
    default:
      return <ProfileSection />
  }
}

function ProfileSection() {
  return (
    <section className="flex flex-col items-center gap-14">
      <div className="w-full max-w-xl rounded-[48px] border-2 border-[#d2bcff] bg-[#f7f0ff] px-10 py-14 text-center shadow-[0_18px_0_#e1d0ff]">
        <h2 className="text-3xl font-bold text-[#2f1c5a]">Change Username in this Project</h2>

        <div className="mt-12 flex flex-col gap-10">
          <div className="relative">
            <Search className="absolute left-7 top-1/2 size-5 -translate-y-1/2 text-[#b09ce5]" />
            <input
              defaultValue="Username 1"
              className="w-full rounded-full border-2 border-[#c7b2ff] bg-white/90 px-16 py-4 text-lg font-semibold text-[#3a2d6d] shadow-[0_10px_0_#e3d4ff] focus:outline-none focus:ring-2 focus:ring-[#8f75ff]"
            />
          </div>

          <button
            type="button"
            className="mx-auto inline-flex items-center justify-center rounded-full bg-[#3d347e] px-16 py-4 text-lg font-semibold text-white shadow-[0_8px_0_#2a245d] transition-transform hover:-translate-y-0.5"
          >
            Save
          </button>
        </div>
      </div>
    </section>
  )
}

function MemberSection() {
  type MemberTagVariant = "head" | "member" | "registration" | "account" | "add-department"

  type MemberRow = {
    name: string
    email: string
    role: { label: string; variant: MemberTagVariant }
    department: { label: string; variant: MemberTagVariant; withDropdown?: boolean }
  }

  const members: MemberRow[] = [
    {
      name: "Username 1",
      email: "email1@mail.com",
      role: { label: "Head", variant: "head" },
      department: { label: "Registration", variant: "registration" },
    },
    {
      name: "Username 2",
      email: "email2@mail.com",
      role: { label: "Member", variant: "member" },
      department: { label: "Registration", variant: "registration" },
    },
    {
      name: "Username 3",
      email: "email3@mail.com",
      role: { label: "Member", variant: "member" },
      department: { label: "Account", variant: "account" },
    },
    {
      name: "Username 4",
      email: "email4@mail.com",
      role: { label: "Member", variant: "member" },
      department: { label: "Add Department", variant: "add-department", withDropdown: true },
    },
  ]

  return (
    <section className="flex flex-col gap-10">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-[#2f1c5a]">Project Members</h2>
          <p className="text-base text-[#7263aa]">Overview of participants and their roles.</p>
        </div>
        <SearchInput className="md:w-80" />
      </div>

      <div className="flex flex-col gap-6">
        {members.map((member) => (
          <div
            key={member.email}
            className="flex flex-col gap-4 rounded-full border border-[#d8c8ff] bg-[#f7f1ff] px-6 py-4 text-[#2f1c5a] shadow-[0_8px_0_rgba(164,131,255,0.12)] transition-transform hover:-translate-y-0.5 md:flex-row md:items-center md:gap-6 md:px-8 md:py-5"
          >
            <div className="flex flex-1 items-center gap-4">
              <div className="flex size-14 items-center justify-center rounded-full bg-[#e2d4ff] text-[#4d3e86] shadow-[0_6px_0_rgba(62,45,120,0.12)]">
                <UserRound className="size-6" />
              </div>
              <div className="flex flex-col gap-1 text-left">
                <span className="text-lg font-semibold">{member.name}</span>
                <span className="text-sm text-[#7d6ab7]">{member.email}</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3 md:flex-none">
              <MemberTag label={member.role.label} variant={member.role.variant} />
              <MemberTag
                label={member.department.label}
                variant={member.department.variant}
                withDropdown={member.department.withDropdown}
              />
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

type MemberTagProps = {
  label: string
  variant: "head" | "member" | "registration" | "account" | "add-department"
  withDropdown?: boolean
}

function MemberTag({ label, variant, withDropdown }: MemberTagProps) {
  const baseClass =
    "inline-flex items-center gap-2 rounded-full px-6 py-2 text-sm font-semibold shadow-[0_6px_0_rgba(62,45,120,0.12)]"
  const variantClass = (() => {
    switch (variant) {
      case "head":
        return "bg-[#b49aff] text-white"
      case "registration":
        return "bg-[#d6e9ff] text-[#395f96]"
      case "account":
        return "bg-[#d9f7c9] text-[#3d6935]"
      case "add-department":
        return "border border-dashed border-[#ceb9ff] bg-white/80 text-[#9080d8]"
      case "member":
      default:
        return "bg-white text-[#4c3e86] border border-[#d7c6ff]"
    }
  })()

  return (
    <span className={`${baseClass} ${variantClass}`}>
      {label}
      {withDropdown ? <ChevronDown className="size-4 text-current" /> : null}
    </span>
  )
}

function DepartmentSection() {
  const departments = [
    {
      title: "Account",
      headLabel: "Select",
      members: 1,
      accent: "bg-[#d9f8c6] border-[#bfe68e] shadow-[0_14px_0_#cbeeb0]",
      colorButton: "bg-white text-[#5a8a3a]",
    },
    {
      title: "Registration",
      headLabel: "Username 1",
      members: 2,
      accent: "bg-[#d8eaff] border-[#a9cdfc] shadow-[0_14px_0_#bcd9ff]",
      colorButton: "bg-white text-[#3b5d9a]",
    },
  ]

  return (
    <section className="flex flex-col gap-12">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-[#2f1c5a]">Departments</h2>
          <p className="text-base text-[#7263aa]">Structure your team into meaningful units.</p>
        </div>
        <SearchInput />
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        {departments.map((department) => (
          <div
            key={department.title}
            className={`rounded-[36px] border-2 px-8 py-10 text-[#2f1c5a] ${department.accent}`}
          >
            <h3 className="text-2xl font-bold">{department.title}</h3>

            <div className="mt-8 space-y-5 text-base font-semibold text-[#43357c]">
              <div className="space-y-1">
                <p>Head :</p>
                <div className="relative">
                  <ChevronDown className="absolute right-4 top-1/2 size-5 -translate-y-1/2 text-[#7263aa]" />
                  <div className="w-full rounded-full border-2 border-white/70 bg-white/60 px-4 py-3">
                    {department.headLabel}
                  </div>
                </div>
              </div>

              <p>
                Number of Member : <span className="font-bold">{department.members}</span>
              </p>
            </div>

            <button
              type="button"
              className={`mt-10 flex w-full items-center justify-center rounded-full px-4 py-3 text-base font-semibold shadow-[0_8px_0_rgba(62,45,120,0.12)] ${department.colorButton}`}
            >
              Select Color
            </button>
          </div>
        ))}

        <div className="flex flex-col items-center justify-center rounded-[36px] border-2 border-dashed border-[#cbb5ff] bg-[#f7f0ff] px-8 py-10 text-center text-[#8a76c9] shadow-[0_14px_0_#e5d6ff]">
          <Plus className="mb-4 size-10" strokeWidth={1.5} />
          <span className="text-2xl font-bold">Add Department</span>
        </div>
      </div>
    </section>
  )
}

function TaskSection() {
  const tasks = [
    {
      title: "Task 1",
      deadline: "DD/MM/YYYY",
      assignee: "Username 1",
      status: "Submitted",
      statusClass: "bg-[#d6c2ff] text-[#2f1c5a]",
    },
    {
      title: "Task 2",
      deadline: "DD/MM/YYYY",
      assignee: "Username 2",
      status: "In Progress",
      statusClass: "bg-white text-[#2f1c5a]",
    },
  ]

  return (
    <section className="flex flex-col gap-10">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap items-center gap-4">
          <button className="flex items-center gap-3 rounded-full border-2 border-[#a9cdfc] bg-[#d8eaff] px-6 py-3 text-base font-semibold text-[#2f1c5a] shadow-[0_8px_0_#bcd9ff]">
            <span>Registration</span>
            <ChevronDown className="size-4" />
          </button>
          <div className="flex items-center gap-3 rounded-full border-2 border-[#c7b2ff] bg-white/80 px-5 py-3 text-base font-semibold text-[#2f1c5a] shadow-[0_8px_0_#e3d4ff]">
            <CalendarDays className="size-5 text-[#7f6ccd]" />
            <span>September</span>
          </div>
        </div>
        <SearchInput />
      </div>

      <div className="rounded-[36px] border-2 border-[#d2bcff] bg-[#f7f0ff] px-10 py-10 shadow-[0_14px_0_#e1d0ff]">
        <div className="flex flex-col gap-6">
          {tasks.map((task) => (
            <div
              key={task.title}
              className="flex flex-col gap-4 rounded-full border-2 border-[#d2bcff] bg-white/80 px-6 py-4 text-[#2f1c5a] shadow-[0_10px_0_rgba(62,45,120,0.1)] md:flex-row md:items-center"
            >
              <div className="flex flex-col gap-1 md:w-1/2">
                <span className="text-2xl font-bold">{task.title}</span>
                <span className="text-sm text-[#7263aa]">
                  Deadline : {task.deadline} · Assigned to : {task.assignee}
                </span>
              </div>
              <div className="flex flex-1 items-center justify-end gap-4">
                <span
                  className={`rounded-full px-6 py-2 text-sm font-semibold shadow-[0_6px_0_rgba(62,45,120,0.15)] ${task.statusClass}`}
                >
                  {task.status}
                </span>
              </div>
            </div>
          ))}

          <button className="flex items-center justify-between rounded-full border-2 border-[#d2bcff] bg-white/60 px-6 py-4 text-lg font-semibold text-[#6c5a9d] shadow-[0_10px_0_rgba(62,45,120,0.1)] transition-all hover:-translate-y-0.5 hover:bg-white">
            <div className="flex items-center gap-3">
              <Plus className="size-6" />
              <span>Create Task</span>
            </div>
            <ChevronRight className="size-5" />
          </button>
        </div>
      </div>
    </section>
  )
}

function CalendarSection() {
  const weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
  const dates = [
    ["", "", "", "", "", "", ""],
    ["1", "2", "3", "4", "5", "6", "7"],
    ["8", "9", "10", "11", "12", "13", "14"],
    ["15", "16", "17", "18", "19", "20", "21"],
    ["22", "23", "24", "25", "26", "27", "28"],
    ["29", "30", "", "", "", "", ""],
  ]

  return (
    <section className="flex flex-col gap-10">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-4">
          <button className="flex size-12 items-center justify-center rounded-full border-2 border-[#d2bcff] bg-white/70 text-[#6c5a9d] shadow-[0_8px_0_#e3d4ff]">
            <ChevronLeft className="size-5" />
          </button>
          <div className="rounded-full border-2 border-[#d2bcff] bg-white px-10 py-3 text-xl font-bold text-[#2f1c5a] shadow-[0_8px_0_#e3d4ff]">
            September
          </div>
          <button className="flex size-12 items-center justify-center rounded-full border-2 border-[#d2bcff] bg-white/70 text-[#6c5a9d] shadow-[0_8px_0_#e3d4ff]">
            <ChevronRight className="size-5" />
          </button>
        </div>
        <SearchInput className="md:w-72" />
      </div>

      <div className="rounded-[36px] border-2 border-[#d2bcff] bg-[#f7f0ff] px-8 py-10 shadow-[0_14px_0_#e1d0ff]">
        <div className="grid grid-cols-7 gap-4 text-center text-sm font-semibold uppercase tracking-[0.25em] text-[#a28edc]">
          {weekDays.map((day) => (
            <span key={day}>{day}</span>
          ))}
        </div>

        <div className="mt-6 grid grid-cols-7 gap-4 text-lg font-semibold text-[#2f1c5a]">
          {dates.flat().map((date, index) => (
            <div
              key={`${date}-${index}`}
              className={`flex h-24 flex-col justify-between rounded-3xl border-2 border-[#e5d6ff] bg-white/60 px-4 py-3 ${
                date ? "shadow-[0_8px_0_rgba(62,45,120,0.08)]" : "border-transparent bg-transparent shadow-none"
              }`}
            >
              <span>{date}</span>
              {renderCalendarBadge(date)}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function renderCalendarBadge(date: string) {
  if (date === "8") {
    return (
      <span className="inline-flex items-center gap-2 rounded-full bg-[#d8eaff] px-3 py-1 text-xs font-semibold text-[#2f1c5a]">
        <CheckCircle2 className="size-4" />
        Task 1
      </span>
    )
  }

  if (date === "10") {
    return (
      <span className="inline-flex items-center gap-2 rounded-full bg-[#c9b6ff] px-3 py-1 text-xs font-semibold text-white">
        <CheckCircle2 className="size-4" />
        Submitted
      </span>
    )
  }

  if (date === "13") {
    return (
      <span className="inline-flex items-center gap-2 rounded-full bg-[#c7b2ff] px-3 py-1 text-xs font-semibold text-[#2f1c5a]">
        <CheckCircle2 className="size-4" />
        In Progress
      </span>
    )
  }

  if (date === "9") {
    return (
      <span className="inline-flex items-center gap-2 rounded-full bg-[#bcd9ff] px-3 py-1 text-xs font-semibold text-[#2f1c5a]">
        <CheckCircle2 className="size-4" />
        Task 2
      </span>
    )
  }

  return <span />
}

type SearchInputProps = {
  className?: string
}

function SearchInput({ className }: SearchInputProps) {
  return (
    <div className={`relative w-full max-w-sm ${className ?? ""}`}>
      <Search className="absolute left-6 top-1/2 size-5 -translate-y-1/2 text-[#b09ce5]" />
      <input className={SEARCH_INPUT_CLASS} placeholder="Search" />
    </div>
  )
}
