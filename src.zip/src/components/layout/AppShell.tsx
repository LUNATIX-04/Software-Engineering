"use client"

import {
  ReactNode,
  SetStateAction,
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react"
import { usePathname, useRouter } from "next/navigation"
import Image from "next/image"
import { User as UserIcon } from "lucide-react"
import type { Session } from "@supabase/supabase-js"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { SettingsForm } from "@/components/settings/SettingsForm"

import { cn } from "@/lib/utils"
import { getSupabaseBrowserClient } from "@/utils/supabase/client"
import { DropdownMenuLabel } from "@radix-ui/react-dropdown-menu"

const DEPARTMENT_LAYOUTS = ["compact", "fullWidth"] as const
export type DepartmentLayoutOption = (typeof DEPARTMENT_LAYOUTS)[number]

const THEME_OPTIONS = ["standard", "light", "dark", "red", "blue"] as const
export type ThemeOption = (typeof THEME_OPTIONS)[number]

const THEME_LABELS: Record<ThemeOption, string> = {
  standard: "Standard",
  light: "Light",
  dark: "Dark",
  red: "Red",
  blue: "Blue",
}

const THEME_SWATCHES: Record<ThemeOption, string[]> = {
  standard: ["#907ad6", "#4f518c", "#f4effa"],
  light: ["#2563eb", "#a5b4fc", "#fdfbff"],
  dark: ["#111827", "#6366f1", "#0ea5e9"],
  red: ["#e11d48", "#fecdd3", "#fff5f5"],
  blue: ["#1d4ed8", "#38bdf8", "#e6f4ff"],
}

const DEPARTMENT_LABELS: Record<DepartmentLayoutOption, string> = {
  compact: "Compact chips",
  fullWidth: "Full-width chips",
}

type ProfileSummary = {
  id: string
  email: string
  fullName: string | null
  avatarUrl: string | null
  lastSignIn: string | null
  departmentLayout: DepartmentLayoutOption
  theme: ThemeOption
}

type PreferencesContextValue = {
  profile: ProfileSummary | null
  loading: boolean
  refreshProfile: () => Promise<void>
  updateProfileLocally: (update: Partial<ProfileSummary>) => void
}

const PreferencesContext = createContext<PreferencesContextValue>({
  profile: null,
  loading: false,
  refreshProfile: async () => {},
  updateProfileLocally: () => {},
})

function ensureDepartmentLayout(value: unknown): DepartmentLayoutOption {
  return DEPARTMENT_LAYOUTS.includes(value as DepartmentLayoutOption)
    ? (value as DepartmentLayoutOption)
    : "fullWidth"
}

function ensureTheme(value: unknown): ThemeOption {
  return THEME_OPTIONS.includes(value as ThemeOption) ? (value as ThemeOption) : "standard"
}

export function usePreferences() {
  return useContext(PreferencesContext)
}

type AppShellProps = {
  children: ReactNode
}

type SignOutRedirect = "homepage" | "google" | "none"

export default function AppShell({ children }: AppShellProps) {
  const pathname = usePathname()
  const router = useRouter()
  const isHomepage = pathname === "/Homepage"
  const isProjects = pathname?.startsWith("/Projects") ?? false
  const [accountMenuOpen, setAccountMenuOpen] = useState(false)
  const supabase = useMemo(() => getSupabaseBrowserClient(), [])
  const [session, setSession] = useState<Session | null>(null)
  const [authLoading, setAuthLoading] = useState(true)
  const [profile, setProfile] = useState<ProfileSummary | null>(null)
  const [preferencesLoading, setPreferencesLoading] = useState(false)
  const [manageDialogOpen, setManageDialogOpen] = useState(false)
  const [settingsDialogOpen, setSettingsDialogOpen] = useState(false)
  const authenticatedUser = session?.user ?? null

  const applyTheme = useCallback((theme: ThemeOption) => {
    if (typeof document === "undefined") {
      return
    }
    const body = document.body
    const root = document.documentElement
    if (theme === "standard") {
      if (body) {
        delete body.dataset.theme
      }
      delete root.dataset.theme
    } else {
      if (body) {
        body.dataset.theme = theme
      }
      root.dataset.theme = theme
    }
    document.documentElement.classList.toggle("dark", theme === "dark")
  }, [])

  const updateProfileLocally = useCallback((update: Partial<ProfileSummary>) => {
    setProfile((prev) => {
      if (!prev) {
        return prev
      }
      const normalizedTheme = ensureTheme(update.theme ?? prev.theme)
      const normalizedDepartment = ensureDepartmentLayout(
        update.departmentLayout ?? prev.departmentLayout
      )
      return {
        ...prev,
        ...update,
        theme: normalizedTheme,
        departmentLayout: normalizedDepartment,
      }
    })
  }, [])

  const refreshProfile = useCallback(async () => {
    if (!authenticatedUser) {
      setProfile(null)
      setPreferencesLoading(false)
      return
    }

    setPreferencesLoading(true)
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select(
          "id, email, full_name, avatar_url, last_sign_in, department_layout, theme"
        )
        .eq("id", authenticatedUser.id)
        .maybeSingle()

      if (error) {
        console.error("Failed to load profile preferences", error)
        return
      }

      if (data) {
        setProfile({
          id: data.id,
          email: data.email,
          fullName: data.full_name ?? null,
          avatarUrl: data.avatar_url ?? null,
          lastSignIn: data.last_sign_in ?? null,
          departmentLayout: ensureDepartmentLayout(data.department_layout),
          theme: ensureTheme(data.theme),
        })
      } else {
        setProfile({
          id: authenticatedUser.id,
          email: authenticatedUser.email ?? "",
          fullName:
            (authenticatedUser.user_metadata?.full_name as string | null) ?? null,
          avatarUrl:
            (authenticatedUser.user_metadata?.avatar_url as string | null) ?? null,
          lastSignIn: authenticatedUser.last_sign_in_at ?? null,
          departmentLayout: "fullWidth",
          theme: "standard",
        })
      }
    } finally {
      setPreferencesLoading(false)
    }
  }, [authenticatedUser, supabase])

  useEffect(() => {
    let isMounted = true

    supabase.auth.getSession().then(({ data }: { data: { session: Session | null } }) => {
      if (!isMounted) return
      setSession(data.session ?? null)
      setAuthLoading(false)
    })

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event: any, nextSession: SetStateAction<Session | null>) => {
      setSession(nextSession)
      setAuthLoading(false)
    })

    return () => {
      isMounted = false
      subscription.unsubscribe()
    }
  }, [supabase])

  useEffect(() => {
    if (authLoading) {
      return
    }
    refreshProfile()
  }, [authLoading, refreshProfile])

  useEffect(() => {
    const nextTheme = profile?.theme ?? "standard"
    applyTheme(nextTheme)
  }, [profile?.theme, applyTheme])

  useEffect(() => {
    if (!authenticatedUser) {
      setManageDialogOpen(false)
      setSettingsDialogOpen(false)
    }
  }, [authenticatedUser])

  const lastSignInDisplay = useMemo(() => {
    if (!profile?.lastSignIn) {
      return "Not available"
    }
    const parsed = new Date(profile.lastSignIn)
    if (Number.isNaN(parsed.getTime())) {
      return "Not available"
    }
    try {
      return parsed.toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      })
    } catch {
      return parsed.toISOString()
    }
  }, [profile?.lastSignIn])

  const themeLabel = THEME_LABELS[profile?.theme ?? "standard"]
  const themePreviewSwatches = THEME_SWATCHES[profile?.theme ?? "standard"]
  const departmentLabel =
    (profile && DEPARTMENT_LABELS[profile.departmentLayout]) || DEPARTMENT_LABELS.fullWidth
  const handleGoogleSignIn = useCallback(async () => {
    setAuthLoading(true)
    const {
      data: { url },
      error,
    } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
      },
    })

    if (error) {
      console.error("Failed to sign in with Google", error)
      setAuthLoading(false)
      return
    }

    if (url) {
      window.location.assign(url)
    }
  }, [supabase])

  const handleSignOut = useCallback(async (options?: { redirect?: SignOutRedirect }) => {
    setAuthLoading(true)
    const { error } = await supabase.auth.signOut()
    if (error) {
      console.error("Failed to sign out", error)
      setAuthLoading(false)
      return
    }
    setAccountMenuOpen(false)
    const redirect = options?.redirect ?? "homepage"
    if (redirect === "google") {
      await handleGoogleSignIn()
      return
    }
    setAuthLoading(false)
    if (redirect === "homepage") {
      router.push("/Homepage")
    }
  }, [handleGoogleSignIn, router, supabase])

  const handleLogoClick = useCallback(() => {
    if (isHomepage) {
      return
    }
    router.push("/Homepage")
  }, [isHomepage, router])

  const avatarUrl =
    (authenticatedUser?.user_metadata?.avatar_url as string | undefined) ?? undefined

  const avatar = authenticatedUser ? (
    avatarUrl ? (
      <Image
        src={avatarUrl}
        alt="User avatar"
        width={36}
        height={36}
        className="size-full rounded-full object-cover"
        priority
      />
    ) : (
      <div className="flex size-full items-center justify-center rounded-full bg-button-background-on-nav text-button-foreground-on-nav text-sm font-semibold">
        {authenticatedUser.email?.[0]?.toUpperCase() ?? "U"}
      </div>
    )
  ) : (
    <UserIcon className="size-7 text-button-foreground-on-nav" />
  )

  const renderAccountDropdown = (redirect: SignOutRedirect) => {
    if (!authenticatedUser) {
      return null
    }

    return (
      <DropdownMenu modal={false} onOpenChange={setAccountMenuOpen}>
        <DropdownMenuTrigger asChild>
          <Button
            variant="secondary"
            size="icon"
            className={cn(
              "bg-button-background-on-nav hover:bg-button-hover-background-on-nav active:bg-button-hover-background-on-nav rounded-full size-9 p-0 transition-colors select-none",
              accountMenuOpen && "ring-2 ring-button-foreground-on-nav/40"
            )}
            aria-pressed={accountMenuOpen}
          >
            {avatar}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          align="end"
          className="bg-button-background-on-nav text-button-foreground-on-nav border-none rounded-2xl p-2"
        >
          <DropdownMenuLabel className="text-button-foreground-on-nav rounded-xl py-3 px-4 cursor-text text-base">
            {authenticatedUser.email ?? "My Account"}
          </DropdownMenuLabel>
          <DropdownMenuItem
            className="text-button-foreground-on-nav hover:bg-button-hover-background-on-nav rounded-xl py-3 px-4 cursor-pointer text-base"
            onSelect={() => {
              setAccountMenuOpen(false)
              setManageDialogOpen(true)
            }}
          >
            Manage my Account
          </DropdownMenuItem>
          <DropdownMenuItem
            className="text-button-foreground-on-nav hover:bg-button-hover-background-on-nav rounded-xl py-3 px-4 cursor-pointer text-base"
            onSelect={() => {
              setAccountMenuOpen(false)
              setSettingsDialogOpen(true)
            }}
          >
            Settings
          </DropdownMenuItem>
          <DropdownMenuItem
            className="text-button-foreground-on-nav hover:bg-button-hover-background-on-nav rounded-xl py-3 px-4 cursor-pointer text-base"
            onSelect={() => handleSignOut({ redirect })}
          >
            Log out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    )
  }

  const header = (() => {
    if (isHomepage) {
      return (
        <header className="fixed inset-x-0 top-0 z-50 bg-primary px-[clamp(1.5rem,1vw,3rem)] py-[clamp(0.6rem,1vh,1rem)] ">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-[clamp(1.5rem,7vw,7rem)]">
              <button
                type="button"
                onClick={handleLogoClick}
                disabled={isHomepage}
                className={cn(
                  "rounded-full bg-transparent p-0 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-button-foreground-on-nav/40",
                  isHomepage ? "cursor-default" : "cursor-pointer"
                )}
                aria-label={isHomepage ? "ASAP" : "Go to homepage"}
              >
                <span
                  className="text-primary-foreground text-3xl font-bold leading-none select-none"
                  draggable={false}
                  role="heading"
                  aria-level={1}
                >
                  ASAP
                </span>
              </button>
            </div>
            <div className="flex items-center gap-2">
              {authenticatedUser ? (
                renderAccountDropdown("google")
              ) : (
                <Button
                  variant="secondary"
                  className="bg-button-background-on-nav text-button-foreground-on-nav hover:bg-button-hover-background-on-nav rounded-full px-[clamp(2.5rem,5vw,4rem)] py-[clamp(0.5rem,1.6vh,0.85rem)] text-[clamp(1rem,2.1vw,1.15rem)] font-semibold"
                  onClick={handleGoogleSignIn}
                  disabled={authLoading}
                >
                  {authLoading ? "Loading..." : "Login"}
                </Button>
              )}
            </div>
          </div>
        </header>
      )
    }

    if (isProjects) {
      return (
        <header className="fixed inset-x-0 top-0 z-50 bg-primary px-[clamp(1.5rem,1vw,3rem)] py-[clamp(0.6rem,1vh,1rem)] ">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-[clamp(1.5rem,7vw,7rem)]">
              <button
                type="button"
                onClick={handleLogoClick}
                disabled={isHomepage}
                className={cn(
                  "rounded-full bg-transparent p-0 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-button-foreground-on-nav/40",
                  isHomepage ? "cursor-default" : "cursor-pointer"
                )}
                aria-label={isHomepage ? "ASAP" : "Go to homepage"}
              >
                <span
                  className="text-primary-foreground text-3xl font-bold leading-none select-none"
                  draggable={false}
                  role="heading"
                  aria-level={1}
                >
                  ASAP
                </span>
              </button>
            </div>
            <div className="flex items-center gap-2">
              {authenticatedUser ? (
                renderAccountDropdown("homepage")
              ) : (
                <Button
                  variant="secondary"
                  className="bg-button-background-on-nav text-button-foreground-on-nav hover:bg-button-hover-background-on-nav rounded-full px-6 py-2 text-base font-semibold"
                  onClick={handleGoogleSignIn}
                  disabled={authLoading}
                >
                  {authLoading ? "Loading..." : "Login"}
                </Button>
              )}
            </div>
          </div>
        </header>
      )
    }

    return null
  })()

  const hasHeader = Boolean(header)

  const mainClassName = cn(
    "flex-1 bg-background",
    hasHeader && "pt-[clamp(4.5rem,12vh,6rem)]",
    isHomepage && "flex items-center justify-center"
  )

  return (
    <PreferencesContext.Provider
      value={{
        profile,
        loading: preferencesLoading,
        refreshProfile,
        updateProfileLocally,
      }}
    >
      <Dialog open={manageDialogOpen} onOpenChange={setManageDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Manage Account</DialogTitle>
            <DialogDescription>
              Review your account information and current personalization choices.
            </DialogDescription>
          </DialogHeader>
          {preferencesLoading && !profile ? (
            <div className="py-6 text-center text-sm text-muted-foreground">
              Loading your account…
            </div>
          ) : profile ? (
            <div className="space-y-6">
              <div className="grid gap-4 text-sm text-foreground">
                <div className="grid gap-1">
                  <span className="text-xs uppercase tracking-wide text-muted-foreground">
                    Email
                  </span>
                  <span className="font-semibold">{profile.email}</span>
                </div>
                <div className="grid gap-1">
                  <span className="text-xs uppercase tracking-wide text-muted-foreground">
                    Full name
                  </span>
                  <span className="font-semibold">{profile.fullName || "Not provided"}</span>
                </div>
                <div className="grid gap-1">
                  <span className="text-xs uppercase tracking-wide text-muted-foreground">
                    Last sign-in
                  </span>
                  <span className="font-semibold">{lastSignInDisplay}</span>
                </div>
                <div className="grid gap-1">
                  <span className="text-xs uppercase tracking-wide text-muted-foreground">
                    Department layout
                  </span>
                  <span className="font-semibold">{departmentLabel}</span>
                </div>
                <div className="grid gap-2">
                  <span className="text-xs uppercase tracking-wide text-muted-foreground">
                    Theme
                  </span>
                  <span className="font-semibold">{themeLabel}</span>
                  <div className="flex gap-2">
                    {themePreviewSwatches.map((color) => (
                      <span
                        key={color}
                        className="h-8 w-8 rounded-full border border-border"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-6 text-center text-sm text-muted-foreground">
              Please sign in to manage your account.
            </div>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={settingsDialogOpen} onOpenChange={setSettingsDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Settings</DialogTitle>
            <DialogDescription>
              Personalize how project chips and colors appear across the app.
            </DialogDescription>
          </DialogHeader>
          <SettingsForm layout="dialog" />
        </DialogContent>
      </Dialog>
      <div className="min-h-dvh flex flex-col overflow-x-hidden">
        {header}
        <main className={mainClassName}>{children}</main>
        <footer className="bg-footer-bar py-[clamp(1.5rem,1vh,1rem)]">
          <div className="max-w-7xl mx-auto px-6" />
        </footer>
      </div>
    </PreferencesContext.Provider>
  )
}
