"use client"

import * as React from "react"
import * as AlertDialogPrimitive from "@radix-ui/react-alert-dialog"
import * as DialogPrimitive from "@radix-ui/react-dialog"

import { cn } from "@/lib/utils"
import { buttonVariants } from "@/components/ui/button"

type AlertDialogRootProps = React.ComponentPropsWithoutRef<
  typeof AlertDialogPrimitive.Root
>
type DialogRootProps = React.ComponentPropsWithoutRef<typeof DialogPrimitive.Root>

type AlertDialogProps = Omit<AlertDialogRootProps, "modal"> & {
  disableModal?: boolean
}

const AlertDialogDisableModalContext = React.createContext(false)

function useDisableModalContext() {
  return React.useContext(AlertDialogDisableModalContext)
}

function AlertDialog({
  disableModal = false,
  children,
  ...rest
}: AlertDialogProps) {
  const alertProps = rest as AlertDialogRootProps
  const dialogProps = rest as DialogRootProps

  return (
    <AlertDialogDisableModalContext.Provider value={disableModal}>
      {disableModal ? (
        <DialogPrimitive.Root data-slot="alert-dialog" modal={false} {...dialogProps}>
          {children}
        </DialogPrimitive.Root>
      ) : (
        <AlertDialogPrimitive.Root data-slot="alert-dialog" {...alertProps}>
          {children}
        </AlertDialogPrimitive.Root>
      )}
    </AlertDialogDisableModalContext.Provider>
  )
}

function AlertDialogTrigger({
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Trigger>) {
  const disableModal = useDisableModalContext()
  const TriggerComponent = disableModal
    ? DialogPrimitive.Trigger
    : AlertDialogPrimitive.Trigger
  return <TriggerComponent data-slot="alert-dialog-trigger" {...props} />
}

function AlertDialogPortal({
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Portal>) {
  const disableModal = useDisableModalContext()
  const PortalComponent = disableModal
    ? DialogPrimitive.Portal
    : AlertDialogPrimitive.Portal
  return <PortalComponent data-slot="alert-dialog-portal" {...props} />
}

function AlertDialogOverlay({
  className,
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Overlay>) {
  const disableModal = useDisableModalContext()
  const OverlayComponent = disableModal
    ? DialogPrimitive.Overlay
    : AlertDialogPrimitive.Overlay

  return (
    <OverlayComponent
      data-slot="alert-dialog-overlay"
      className={cn(
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50 backdrop-blur-sm",
        disableModal && "pointer-events-none bg-black/40",
        className
      )}
      {...props}
    />
  )
}

function AlertDialogContent({
  className,
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Content>) {
  const disableModal = useDisableModalContext()
  const ContentComponent = disableModal
    ? DialogPrimitive.Content
    : AlertDialogPrimitive.Content

  return (
    <AlertDialogPortal>
      <AlertDialogOverlay />
      <ContentComponent
        data-slot="alert-dialog-content"
        className={cn(
          "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg duration-200 sm:max-w-lg",
          className
        )}
        {...props}
      />
    </AlertDialogPortal>
  )
}

function AlertDialogHeader({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="alert-dialog-header"
      className={cn("flex flex-col gap-2 text-center sm:text-left", className)}
      {...props}
    />
  )
}

function AlertDialogFooter({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="alert-dialog-footer"
      className={cn(
        "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
        className
      )}
      {...props}
    />
  )
}

function AlertDialogTitle({
  className,
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Title>) {
  const disableModal = useDisableModalContext()
  const TitleComponent = disableModal
    ? DialogPrimitive.Title
    : AlertDialogPrimitive.Title

  return (
    <TitleComponent
      data-slot="alert-dialog-title"
      className={cn("text-lg font-semibold", className)}
      {...props}
    />
  )
}

function AlertDialogDescription({
  className,
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Description>) {
  const disableModal = useDisableModalContext()
  const DescriptionComponent = disableModal
    ? DialogPrimitive.Description
    : AlertDialogPrimitive.Description

  return (
    <DescriptionComponent
      data-slot="alert-dialog-description"
      className={cn("text-muted-foreground text-sm", className)}
      {...props}
    />
  )
}

function AlertDialogAction({
  className,
  asChild,
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Action>) {
  const disableModal = useDisableModalContext()

  if (disableModal) {
    const { onClick, ...rest } = props
    return (
      <button
        data-slot="alert-dialog-action"
        type="button"
        className={cn(buttonVariants(), className)}
        onClick={onClick}
        {...rest}
      />
    )
  }

  return (
    <AlertDialogPrimitive.Action
      className={cn(buttonVariants(), className)}
      asChild={asChild}
      {...props}
    />
  )
}

function AlertDialogCancel({
  className,
  asChild,
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Cancel>) {
  const disableModal = useDisableModalContext()

  if (disableModal) {
    const { onClick, ...rest } = props
    return (
      <button
        data-slot="alert-dialog-cancel"
        type="button"
        className={cn(buttonVariants({ variant: "outline" }), className)}
        onClick={onClick}
        {...rest}
      />
    )
  }

  return (
    <AlertDialogPrimitive.Cancel
      className={cn(buttonVariants({ variant: "outline" }), className)}
      asChild={asChild}
      {...props}
    />
  )
}

export {
  AlertDialog,
  AlertDialogPortal,
  AlertDialogOverlay,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
}
